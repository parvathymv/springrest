package com.springmvc.securitydemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class HelloController {

 
    @GetMapping("/login")
    public String login(
            @RequestParam(value = "error", required = false) boolean error,
            @RequestParam(value = "logout", required = false) boolean logout,
            Model model) {
        if (error) {
            model.addAttribute("loginError", true);
        }
        if (logout) {
            model.addAttribute("logoutSuccess", true);
        }
        return "login"; 
    }

   
    @GetMapping("/home")
    public String home() {
        return "home"; 
    }

  
    @GetMapping("/public")
    public String publicPage() {
        return "This is a public page!";
    }
}
